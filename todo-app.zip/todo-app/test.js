async function test() {
  // POST - Create task
  const res = await fetch('http://localhost:3000/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: "Complete backend practice" })
  });
  console.log("Status:", res.status); // 201 ravali
  console.log("Data:", await res.json());

  // GET - All tasks
  const res2 = await fetch('http://localhost:3000/tasks');
  console.log("All tasks:", await res2.json());
}
test();